<script setup>
defineProps(['uang_makan']);
</script>

<template>

</template>
