<script setup>
import MainCard from "@/Components/MainCard.vue";
</script>

<template>
    <MainCard> HELLO WORLD </MainCard>
</template>
